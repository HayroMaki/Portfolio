package fr.codex.naturalis.point.system;

public interface PointSystem {
}
