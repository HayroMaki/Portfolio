package fr.codex.naturalis;

import java.util.ArrayList;
import fr.codex.naturalis.card.Card;

public class Pile {
    private final ArrayList<Card> pile;
    private Card turnedOverCard1;
    private Card turnedOverCard2;

    public Pile() {
        this.pile = new ArrayList<Card>();
        this.turnedOverCard1 = null;
        this.turnedOverCard2 = null;
    }

    @Override
    public String toString() {
        return "Pile{" +
                ", TurnedOverCard1=" + turnedOverCard1 +
                ", TurnedOverCard2=" + turnedOverCard2 +
                ", pile=" + pile +
                '}';
    }
    public Card getFirstOfPile() {
        return pile.getFirst();
    }
    public Card getTOC1() {
        return turnedOverCard1;
    }
    public Card getTOC2() {
        return turnedOverCard2;
    }
    /**
     * set the first turned over card to the first card of the pile, removing it from the pile.
     */
    public void setTOC1() {
        if (!pile.isEmpty()) {
            this.turnedOverCard1 = pile.removeFirst();
            turnedOverCard1.setRecto();
        } else turnedOverCard1 = null;
    }
    /**
     * set the second turned over card to the first card of the pile, removing it from the pile.
     */
    public void setTOC2() {
        if (!pile.isEmpty()) {
            this.turnedOverCard2 = pile.removeFirst();
            turnedOverCard2.setRecto();
        } else turnedOverCard2 = null;
    }
    /**
     * Remove the first turned over card and returns it.
     * Then set the first turned over card to the first card of the pile, removing it from the pile.
     *
     * @return the turned over Card that was removed.
     */
    public Card removeTOC1() {
        var card = turnedOverCard1;
        setTOC1();
        return card;
    }
    /**
     * Remove the second turned over card and returns it.
     * Then set the second turned over card to the first card of the pile, removing it from the pile.
     *
     * @return the turned over Card that was removed.
     */
    public Card removeTOC2() {
        var card = turnedOverCard2;
        setTOC2();
        return card;
    }
    /**
     * Check if the first turned over card is takeable.
     *
     * @return true if not null, false if it is.
     */
    public boolean isTOC1Takeable() {
        return turnedOverCard1 != null;
    }
    /**
     * Check if the second turned over card is takeable.
     *
     * @return true if not null, false if it is.
     */
    public boolean isTOC2Takeable() {
        return turnedOverCard2 != null;
    }
    /**
     * Remove the first card from the pile and returns it.
     *
     * @return the first card of the pile.
     */
    public Card removeFromPile() {
        Card first = pile.removeFirst();
        first.setRecto();
        return first;
    }
    /**
     * Add a card to the pile.
     * @param card the card to add.
     */
    public void add(Card card) {
        pile.add(card);
    }
}
