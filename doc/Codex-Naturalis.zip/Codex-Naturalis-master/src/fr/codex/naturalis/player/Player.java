package fr.codex.naturalis.player;

import fr.codex.naturalis.card.Card;
import fr.codex.naturalis.challenge.Challenge;
import fr.codex.naturalis.challenge.ChallengeCard;

import java.util.List;
import java.util.Objects;

public class Player {
    private final Deck deck;
    private int score;
    private ChallengeCard challenge;

    public Player() {
        this.deck = new Deck();
        this.challenge = null;
    }

    @Override
    public String toString() {
        return "Player{" +
                ", score=" + score +
                ", challenge=" + challenge +
                ", deck=" + deck +
                '}';
    }

    /**
     * Set the challenge card of the player.
     *
     * @param challenge a non-null challenge card.
     */
    public void setChallenge(ChallengeCard challenge) {
        Objects.requireNonNull(challenge);
        this.challenge = challenge;
    }
    /**
     * increase the player's score by the parameter entered.
     *
     * @param point the number of points the player's score will be increased by.
     */
    public void increasePoint(int point) {
        if (point < 0) throw new IllegalArgumentException();
        score += point;
    }
    public void addCard(Card card) {
        Objects.requireNonNull(card);
        deck.add(card);
    }
    public void removeCard(Card card) {
        Objects.requireNonNull(card);
        deck.remove(card);
    }

    public boolean deckIsOpen() { return deck.isOpen; }
    public void setDeckOpen() { deck.isOpen = true; }
    public void setDeckClosed() {
        deck.isOpen = false;
        setAllRecto();
    }

    public List<Card> getCards() { return deck.getCards(); }

    public void addScore(int points) { score += points; }
    public int getScore() { return score; }

    public void flipDeck() {
        for (Card card : deck.getCards()) {
            if (card.isVerso()) card.setRecto();
            else card.setVerso();
        }
    }

    private void setAllRecto() {
        for (Card card : deck.getCards()) card.setRecto();
    }
}
