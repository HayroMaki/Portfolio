package fr.codex.naturalis;

import fr.codex.naturalis.player.Player;

public class Main {
    public static void main(String[] args) {
        var game = new Game(300);
        Player player = new Player();
        player.addScore(19);
        game.start(player);
    }
}
