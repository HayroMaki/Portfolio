package fr.codex.naturalis.card;

import fr.codex.naturalis.corner.Corner;
import fr.codex.naturalis.corner.Ressource;
import fr.codex.naturalis.drawing.CardDrawingSequence;
import fr.codex.naturalis.player.Player;

import java.awt.*;
import java.util.List;
import java.util.Objects;

public class RessourceCard implements Card {
    private final Ressource type;
    private final Corner topLeft;
    private final Corner topRight;
    private final Corner bottomLeft;
    private final Corner bottomRight;
    public boolean topLeftObstructed;
    public boolean topRightObstructed;
    public boolean bottomLeftObstructed;
    public boolean bottomRightObstructed;
    private final int point;
    private boolean isVerso;
    private Point coordinate;
    private boolean isPlaced;


    public RessourceCard(Ressource type, Corner topLeft, Corner topRight, Corner bottomLeft, Corner bottomRight, int point) {
        Objects.requireNonNull(type);
        Objects.requireNonNull(topLeft);
        Objects.requireNonNull(topRight);
        Objects.requireNonNull(bottomLeft);
        Objects.requireNonNull(bottomRight);
        this.type = type;

        this.topLeft = topLeft;
        this.topRight = topRight;
        this.bottomLeft = bottomLeft;
        this.bottomRight = bottomRight;

        topLeftObstructed = false;
        topRightObstructed = false;
        bottomLeftObstructed = false;
        bottomRightObstructed = false;

        if (point < 0) { point = 0;}
        if (point > 5) { point = 5;}
        this.point = point;

        this.isVerso = false; //for later
        this.isPlaced = false;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RessourceCard that = (RessourceCard) o;
        return point == that.point && Objects.equals(type, that.type) && Objects.equals(topLeft, that.topLeft) && Objects.equals(topRight, that.topRight) && Objects.equals(bottomLeft, that.bottomLeft) && Objects.equals(bottomRight, that.bottomRight);
    }
    @Override
    public int hashCode() {
        return Objects.hash(type, topLeft, topRight, bottomLeft, bottomRight, point);
    }
    
    @Override
    public boolean topLeftObstructed() {
        if(!isVerso) {
        	return (topLeftObstructed || topLeft.equals(Corner.invisible));
        }
        return topLeftObstructed;
    }
    @Override
    public boolean topRightObstructed() {
    	if(!isVerso) {
        	return (topRightObstructed || topRight.equals(Corner.invisible));
        }
        return topRightObstructed;
    }
    @Override
    public boolean bottomLeftObstructed() {
        if(!isVerso) {
        	return (bottomLeftObstructed || bottomLeft.equals(Corner.invisible));
        }
        return bottomLeftObstructed;
    }
    @Override
    public boolean bottomRightObstructed() {
    	if(!isVerso) {
        	return (bottomRightObstructed || bottomRight.equals(Corner.invisible));
        }
    	return bottomRightObstructed;
    }
    @Override
    public void setTopLeftObstruction(boolean status) {
        topLeftObstructed = status;
    }
    @Override
    public void setTopRightObstruction(boolean status) {
        topRightObstructed = status;
    }
    @Override
    public void setBottomLeftObstruction(boolean status) {
        bottomLeftObstructed = status;
    }
    @Override
    public void setBottomRightObstruction(boolean status) {
        bottomRightObstructed = status;
    }
    @Override
    public String toString() {
        var str = new StringBuilder("Card :\n");
        str.append(topLeft).append(" | ").append(topRight).append("\n");
        str.append("- - - - ").append(point).append("pts").append(" - - - -\n");
        str.append(bottomLeft).append(" | ").append(bottomRight).append("\n");
        return str.toString();
    }
    @Override
    public void changeCoordinates(int x, int y) {
        if (!isPlaced) {
            this.coordinate = new Point(x, y);
        }
    }
    @Override
    public void place(int x, int y, Player player) {
        changeCoordinates(x, y);
        isPlaced = true;
        topLeft.increase();
        topRight.increase();
        bottomLeft.increase();
        bottomRight.increase();
        player.addScore(getPoint());
    }
    @Override
    public int getXCoordinate() {
        return coordinate.x;
    }
    @Override
    public int getYCoordinate() {
        return coordinate.y;
    }
    @Override
    public Color getColor() {
        return type.getMainColor();
    }
    public Color getSecondaryColor() {
        return type.getSecondaryColor();
    }
    public Color getTertiaryColor() {
        return type.getTertiaryColor();
    }
    @Override
    public List<Corner> getAllCorners() {
        if (!isVerso) {
            return List.of(topLeft,topRight,bottomLeft,bottomRight);
        }
        return List.of(Corner.empty,Corner.empty,Corner.empty,Corner.empty);
    }
    public int getPoint() {
    	if(!isVerso) {
    		return point;
    	}
        return 0;
    }
    @Override
    public boolean isVerso() {
        return isVerso;
    }
    @Override
    public void setVerso() { isVerso = true; }
    @Override
    public void setRecto() { isVerso = false; }

    public Ressource getType() {
        return type;
    }

    public void verso(CardDrawingSequence cds, int ratio, int cornerSize, int x, int y) {
        cds.drawRessource(type, x+ratio/2-cornerSize/2, y+ratio/4-cornerSize/3);
    }
}
