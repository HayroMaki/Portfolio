package fr.codex.naturalis.challenge;

public interface Challenge {
}
