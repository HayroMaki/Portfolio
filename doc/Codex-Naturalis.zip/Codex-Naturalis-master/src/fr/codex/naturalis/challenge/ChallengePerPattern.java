package fr.codex.naturalis.challenge;

public class ChallengePerPattern implements Challenge {
}
