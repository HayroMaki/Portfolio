package fr.codex.naturalis.challenge;

public class ChallengePerRessource implements Challenge {
}
