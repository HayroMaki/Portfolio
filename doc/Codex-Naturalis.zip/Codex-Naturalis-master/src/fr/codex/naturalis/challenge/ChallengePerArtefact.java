package fr.codex.naturalis.challenge;

public class ChallengePerArtefact implements Challenge {
}
